/**
 * Frontend mirror of the backend validation rules so users get instant feedback.
 */
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const PASSWORD_RE = /^(?=.*[A-Z])(?=.*[!@#$%^&*(),.?":{}|<>_\-[\]\\/;'`~+=]).{8,16}$/

export function validateName(name) {
  if (!name || name.trim().length < 20 || name.trim().length > 60) {
    return "Name must be between 20 and 60 characters."
  }
  return ""
}

export function validateEmail(email) {
  if (!email || !EMAIL_RE.test(email)) return "Enter a valid email address."
  return ""
}

export function validateAddress(address) {
  if (!address || !address.trim()) return "Address is required."
  if (address.length > 400) return "Address must be at most 400 characters."
  return ""
}

export function validatePassword(password) {
  if (!password || !PASSWORD_RE.test(password)) {
    return "8-16 chars, with at least one uppercase letter and one special character."
  }
  return ""
}
